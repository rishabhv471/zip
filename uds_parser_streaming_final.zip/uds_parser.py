import re
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass

# Constants from C# Constants.resx
FUNCTIONAL_ADDRESS_LIST = "7DF|18DB33F1|-DF|-EF|1DD01FFF|18DBEFF1"

@dataclass
class TraceMessage:
    ecu_address: str
    tester_address: str
    request: str
    response: str
    ecu_extended_address: str = ""
    tester_extended_address: str = ""

def parse_uds_trace(trace_lines: List[str]) -> List[Dict]:
    """Simple UDS trace parser for format: < 165 50 c0 00 00 00 00 00 00"""
    result = []
    for line in trace_lines:
        line = line.strip()
        if not line or not line.startswith('<'):
            continue
        parts = line[1:].strip().split()
        if len(parts) < 2:
            continue
        try:
            msg_id = int(parts[0], 16)
            data = [int(x, 16) for x in parts[1:]]
            result.append({
                'id': msg_id, 
                'data': data,
                'hex_data': ' '.join(parts[1:])
            })
        except ValueError:
            continue
    return result

def parse_samdia_trace(raw_data: str) -> List[TraceMessage]:
    """Complete Samdia format parser with all C# functionality"""
    try:
        # Stage 0: Prepare trace
        prepared_lines = _prepare_trace_for_processing(raw_data)
        if not prepared_lines:
            return []
        
        # Stage 0.5: Get valid CAN IDs
        valid_can_ids, valid_can_ids_with_ext = _get_valid_can_ids(prepared_lines)
        
        # Stage 1: Merge CAN frames
        merged_frames = _merge_can_frames(prepared_lines, valid_can_ids, valid_can_ids_with_ext)
        
        # Stage 2: Find request-response pairs
        request_response_pairs = _find_request_response_address_pairs(merged_frames, prepared_lines)
        
        # Stage 3: Remove functional messages
        filtered_messages, functional_messages = _remove_functional_messages(
            merged_frames, list(request_response_pairs.keys())
        )
        
        # Stage 4: Process request-response pairs
        trace_data = []
        for req_addr, resp_addr in request_response_pairs.items():
            ecu_address = req_addr.split('-')[0]
            tester_address = resp_addr.split('-')[0]
            ecu_ext_addr = req_addr.split('-')[1] if '-' in req_addr else ""
            tester_ext_addr = resp_addr.split('-')[1] if '-' in resp_addr else ""
            
            filtered_trace = _filter_trace(filtered_messages, [req_addr, resp_addr])
            req_resp_pairs = _get_request_response_pairs(filtered_trace, req_addr, resp_addr)
            
            for request, responses in req_resp_pairs.items():
                for response in responses:
                    trace_data.append(TraceMessage(
                        ecu_address=ecu_address,
                        tester_address=tester_address,
                        request=request,
                        response=response,
                        ecu_extended_address=ecu_ext_addr,
                        tester_extended_address=tester_ext_addr
                    ))
        
        # Stage 5: Process functional messages
        trace_data.extend(_process_functional_messages(functional_messages))
        
        return [msg.__dict__ for msg in trace_data]
        
    except Exception as e:
        raise Exception(f"Samdia parsing failed: {str(e)}")

def _prepare_trace_for_processing(trace: str) -> List[str]:
    """Clean timestamps and format trace lines"""
    output = []
    regex1 = re.compile(r'([0-9][0-9]:[0-9][0-9]:[0-9][0-9].[0-9][0-9][0-9].[0-9][0-9][0-9])')
    regex2 = re.compile(r'  .*        ')
    
    for line in trace.splitlines():
        cleaned = regex2.sub(' ', regex1.sub(' ', line)).upper().strip()
        if cleaned:
            output.append(cleaned + '\n')
    return output

def _get_valid_can_ids(input_data: List[str]) -> Tuple[List[str], List[str]]:
    """Get valid CAN IDs with extended address support"""
    can_addresses = _get_can_addresses(input_data)
    can_ext_addresses = _get_can_ext_address(can_addresses)
    
    valid_can_ids = []
    valid_can_ids_with_ext = []
    
    # Process extended addresses
    for can_addr, ext_data in can_ext_addresses.items():
        is_extended_valid = True
        frames_to_analyze = []
        
        for ext_addr, messages in ext_data.items():
            if not _is_valid_diagnostic_frames(messages):
                # Check if all are flow control messages
                flow_control_count = sum(1 for msg in messages if msg.startswith('30'))
                if flow_control_count != len(messages):
                    is_extended_valid = False
                    break
            
            temp_key = f"{can_addr}-{ext_addr}"
            
            if not frames_to_analyze:
                frames_to_analyze = _get_valid_diagnostic_frames_as_list(input_data, [can_addr])
            
            formatted_frames = _merge_can_frames(frames_to_analyze, valid_can_ids, [temp_key])
            
            if not any(temp_key in frame for frame in formatted_frames):
                flow_control_count = sum(1 for msg in messages if msg.startswith('30'))
                if flow_control_count != len(messages):
                    is_extended_valid = False
                    break
            
            if can_addr not in valid_can_ids:
                valid_can_ids.append(can_addr)
            if temp_key not in valid_can_ids_with_ext:
                valid_can_ids_with_ext.append(temp_key)
        
        if not is_extended_valid:
            # Remove invalid extended addresses
            valid_can_ids_with_ext = [x for x in valid_can_ids_with_ext if not x.startswith(f"{can_addr}-")]
    
    # Process regular addresses
    for address, messages in can_addresses.items():
        if not _is_valid_diagnostic_frames(messages):
            continue
        if address not in valid_can_ids:
            valid_can_ids.append(address)
        
        # Don't add as extended if already has extended addresses
        has_extended = any(x.startswith(f"{address}-") for x in valid_can_ids_with_ext)
        if not has_extended and address not in valid_can_ids_with_ext:
            valid_can_ids_with_ext.append(address)
    
    return valid_can_ids, valid_can_ids_with_ext

def _get_can_addresses(input_data: List[str]) -> Dict[str, List[str]]:
    """Extract CAN addresses and payloads"""
    can_addresses = {}
    for line in input_data:
        address, payload = _get_address(line)
        if address and payload:
            if address not in can_addresses:
                can_addresses[address] = []
            can_addresses[address].append(payload)
    return can_addresses

def _get_can_ext_address(can_addresses: Dict[str, List[str]]) -> Dict[str, Dict[str, List[str]]]:
    """Extract extended addresses from CAN data"""
    can_ext_addresses = {}
    
    for address, frame_data in can_addresses.items():
        extended_data = {}
        for frame in frame_data:
            if len(frame) < 6:  # Need at least 3 bytes
                continue
            ext_addr = frame[:2]
            
            if ext_addr not in extended_data:
                extended_data[ext_addr] = []
            extended_data[ext_addr].append(frame[2:].strip())
        
        can_ext_addresses[address] = extended_data
    
    return can_ext_addresses

def _get_address(can_frame: str) -> Tuple[str, str]:
    """Extract address and payload from CAN frame"""
    # 11-bit address
    match = re.search(r' [A-F0-9]{3} ', can_frame)
    if not match:
        # 29-bit address
        match = re.search(r' [A-F0-9]{8} ', can_frame)
    
    if not match:
        return '', ''
    
    address = match.group().strip()
    payload = can_frame[can_frame.index(match.group()):].replace(address, '').strip()
    payload = payload.replace(' ', '')
    
    return address, payload

def _is_valid_diagnostic_frames(can_messages: List[str]) -> bool:
    """Comprehensive diagnostic frame validation with CAN FD support"""
    if not can_messages:
        return False
    
    valid_frames = 0
    
    for i, message in enumerate(can_messages):
        if not re.match(r'^[A-F0-9]+$', message):
            continue
        
        payload = message
        frame_byte_length = len(payload) // 2
        
        if len(payload) < 4 and i < len(can_messages) - 1:
            return False
        
        message_length = payload[:2]
        length_int = int(message_length, 16)
        data_byte_len_in_frame = 7
        
        # CAN FD support
        if length_int == 0 and len(payload) > 4:
            temp_length = payload[1:4]
            temp_length_int = int(temp_length, 16)
            if temp_length_int < 8 or temp_length_int > 62:
                return False
            message_length = temp_length
            length_int = temp_length_int
        
        if (len(payload) // 2) > 8:
            data_byte_len_in_frame = 63
        
        if length_int < 1:
            return False
        
        # Flow control message
        if payload.startswith('30'):
            valid_frames += 1
            continue
        
        message_data = payload[2:].strip()
        if not message_data:
            return False
        
        frame_byte_length -= 1
        
        # Skip continuation and flow control frames
        if message_length.startswith('2') or message_length.startswith('3'):
            continue
        
        # Multi-frame message
        if message_length.startswith('1'):
            if len(payload) < (data_byte_len_in_frame - 1) and i < len(can_messages) - 1:
                return False
            
            message_length = payload[1:4]
            length_int = int(message_length, 16)
            j = i + 1
            byte_length = len(payload[4:]) // 2
            
            # Check flow control sequence
            for j in range(i + 1, len(can_messages)):
                if not can_messages[j].startswith('2'):
                    break
                flow_control_nibble = can_messages[j][1:2]
                fc_int = int(flow_control_nibble, 16)
                expected_fc = (j - i) & 0xF
                if not (fc_int == expected_fc or fc_int == expected_fc - 1):
                    break
                byte_length += (len(can_messages[j]) // 2) - 1
            
            if (byte_length - length_int) < data_byte_len_in_frame and j > i + 1:
                valid_frames += (j - i)
            
            i = j - 1
        else:
            if length_int > frame_byte_length:
                return False
            valid_frames += 1
    
    return valid_frames > 0 and valid_frames > len(can_messages) * 0.8

def _merge_can_frames(input_data: List[str], valid_can_ids: List[str], valid_can_ids_with_ext: List[str]) -> List[str]:
    """Merge multi-frame CAN messages with full C# logic"""
    output = []
    indexes_to_ignore = []
    i = 0
    
    while i < len(input_data):
        if i in indexes_to_ignore:
            i += 1
            continue
        
        address, payload = _get_address(input_data[i])
        if not address or not payload:
            i += 1
            continue
        
        first_byte = payload[:2]
        can_message = payload[2:]
        is_extended_address = False
        
        # Check for extended address
        ext_key = f"{address}-{first_byte}"
        if ext_key in valid_can_ids_with_ext:
            address = ext_key
            first_byte = can_message[:2]
            payload = payload[2:]
            can_message = payload[2:]
            is_extended_address = True
        elif address not in valid_can_ids:
            i += 1
            continue
        
        # CAN FD support
        if first_byte == "00":
            temp_first_byte = can_message[:2]
            temp_byte_int = int(temp_first_byte, 16)
            if temp_byte_int < 8 or temp_byte_int > 62 or (len(can_message) // 2) <= temp_byte_int:
                i += 1
                continue
            first_byte = temp_first_byte
            can_message = can_message[2:]
        
        # Skip partial flow control frames
        if payload.startswith('3') or payload.startswith('2') or can_message.startswith('00'):
            i += 1
            continue
        
        message_length = int(first_byte, 16)
        
        # Multi-frame message
        if payload.startswith('1'):
            can_message = can_message[2:]
            message_length = int(payload[1:4], 16)
            j = i + 1
            i += 1
            appended_length = len(can_message) // 2
            flow_control = -1
            
            while j < len(input_data):
                temp_address, temp_message = _get_address(input_data[j])
                if is_extended_address:
                    temp_address += f"-{temp_message[:2]}"
                    temp_message = temp_message[2:].strip()
                
                if temp_address != address:
                    j += 1
                    continue
                
                if flow_control == -1:
                    flow_control = int(temp_message[1:2], 16)
                
                if not temp_message.startswith(f"2{flow_control:X}"):
                    break
                
                temp_frame = temp_message[2:]
                indexes_to_ignore.append(j)
                appended_length += len(temp_frame) // 2
                can_message += temp_frame
                
                if appended_length >= message_length:
                    break
                
                flow_control += 1
                if flow_control == 16:
                    flow_control = 0
                j += 1
        else:
            if indexes_to_ignore and max(indexes_to_ignore) < i:
                indexes_to_ignore.clear()
            i += 1
        
        # Add complete message
        if len(can_message) >= message_length * 2:
            valid_message = can_message[:message_length * 2]
            output.append(f"{address}\t{valid_message}")
    
    return output

def _find_request_response_address_pairs(merged_frames: List[str], raw_trace: List[str]) -> Dict[str, str]:
    """Find request-response address pairs with complex logic"""
    request_response_pairs = {}
    possible_response_addresses = _get_valid_response_addresses(merged_frames)
    
    valid_response_without_request = {}
    valid_address_count = 0
    
    # Iterative pairing process
    while True:
        valid_response_without_request.clear()
        valid_address_count = len(request_response_pairs)
        
        for response_addr in possible_response_addresses:
            if response_addr in request_response_pairs.values():
                continue
            
            request_addr, request_possibilities = _get_request_address(merged_frames, response_addr)
            
            if not request_addr and request_possibilities:
                valid_response_without_request[response_addr] = request_possibilities
                continue
            elif request_addr:
                if request_addr not in request_response_pairs:
                    request_response_pairs[request_addr] = response_addr
            
            # Filter out processed addresses
            merged_frames = _filter_trace(merged_frames, [response_addr, request_addr], False)
        
        if valid_address_count >= len(request_response_pairs):
            break
    
    # Handle remaining addresses with flow control analysis
    if valid_response_without_request:
        _handle_remaining_addresses(valid_response_without_request, request_response_pairs, raw_trace)
    
    return request_response_pairs

def _get_valid_response_addresses(merged_frames: List[str]) -> List[str]:
    """Find valid response addresses"""
    possible_response_addresses = []
    clubbed_messages = _club_messages(merged_frames)
    
    # Sort by message count (descending)
    ordered_messages = dict(sorted(clubbed_messages.items(), key=lambda x: len(x[1]), reverse=True))
    
    for address, messages in ordered_messages.items():
        is_response_address = True
        for message in messages:
            if not _get_request_sid(message):
                is_response_address = False
                break
        
        if is_response_address:
            possible_response_addresses.append(address)
    
    return possible_response_addresses

def _get_request_address(merged_frames: List[str], response_address: str) -> Tuple[str, List[str]]:
    """Get request address for given response address"""
    # Filter out response pending messages
    regex_pending = re.compile(r'^.*(\t7F[A-F0-9][A-F0-9]78).*$')
    input_filtered = [x for x in merged_frames if not regex_pending.match(x)]
    
    functional_addresses = FUNCTIONAL_ADDRESS_LIST.split('|')
    request_possibilities = []
    request_possibilities_count = 0
    
    for i in range(len(input_filtered) - 1, -1, -1):
        if not input_filtered[i].startswith(response_address):
            continue
        
        parts = input_filtered[i].split('\t')
        if len(parts) != 2:
            continue
        
        response = parts[1]
        response_sid = response[:2]
        
        # Calculate request SID
        if response_sid == "7F" and len(response) >= 4:
            request_sid = response[2:4]
        else:
            try:
                request_sid = f"{int(response_sid, 16) - 0x40:02X}"
            except ValueError:
                continue
        
        # Build search pattern
        search_range = '\n'.join(input_filtered[:i])
        if f"{response_address}\t" in search_range:
            # Handle multiple responses
            matches = list(re.finditer(f"{response_address}\t", search_range))
            if matches:
                data = search_range[matches[-1].start():]
                search_range = data
        
        # Search for request pattern
        request_pattern = request_sid
        if not response.startswith("7F") and len(response) > 2:
            extra_data = response[2:6] if len(response) > 6 else response[2:]
            request_pattern = request_sid + extra_data
        
        # Special case for SID 19
        if request_sid == "19" and len(request_pattern) > 4:
            request_pattern = request_pattern[:4]
        
        # Search for matching requests
        pattern = re.sub(r'[A-F0-9]', '[A-F0-9]', response_address)
        
        # Handle extended addresses
        if '-' in response_address:
            main_addr = response_address.split('-')[0]
            ext_addr = response_address.split('-')[1]
            
            # MB type extended address
            ext_pattern = re.sub(r'[A-F0-9]', '[A-F0-9]', main_addr) + f"-{ext_addr}"
            matches = re.findall(f"{ext_pattern}\t{request_pattern}.*$", search_range, re.MULTILINE)
            
            if not matches:
                # BMW type extended address
                bmw_pattern = re.sub(r'[A-F0-9]', '[A-F0-9]', main_addr[:-2]) + ext_addr + f"-{main_addr[-2:]}"
                matches = re.findall(f"{bmw_pattern}\t{request_pattern}.*$", search_range, re.MULTILINE)
        else:
            matches = re.findall(f"^{pattern}\t{request_pattern}.*$", search_range, re.MULTILINE)
        
        if not matches:
            continue
        
        # Filter out functional addresses
        matching_sids = []
        for match in reversed(matches):
            if any(func_addr in match for func_addr in functional_addresses):
                break
            matching_sids.append(match)
        
        if not matching_sids:
            continue
        
        # Single match found
        if len(matching_sids) == 1:
            return matching_sids[0].split('\t')[0], []
        
        # Multiple matches - collect possibilities
        if request_possibilities_count == 0:
            request_possibilities = [match.split('\t')[0] for match in matching_sids]
            request_possibilities_count = len(request_possibilities)
        else:
            temp_data = [match.split('\t')[0] for match in matching_sids]
            request_possibilities = list(set(request_possibilities) & set(temp_data))
            request_possibilities_count = len(request_possibilities)
    
    if len(request_possibilities) == 1:
        return request_possibilities[0], []
    
    return '', request_possibilities

def _handle_remaining_addresses(valid_response_without_request: Dict[str, List[str]], 
                               request_response_pairs: Dict[str, str], raw_trace: List[str]):
    """Handle remaining addresses using flow control analysis"""
    found_addresses = list(request_response_pairs.keys()) + list(request_response_pairs.values())
    raw_trace_str = _get_valid_diagnostic_frames(raw_trace, found_addresses, False)
    raw_trace_lines = raw_trace_str.splitlines()
    
    for response_addr, request_possibilities in valid_response_without_request.items():
        # Look for multi-frame responses
        multi_frame_pattern = response_addr.replace('-', '[ ]+') + r'[ ]+1[A-F0-9] .*'
        multi_frame_responses = re.findall(multi_frame_pattern, raw_trace_str, re.MULTILINE)
        
        if not multi_frame_responses:
            continue
        
        for possible_request in request_possibilities:
            if possible_request in request_response_pairs:
                continue
            
            # Check flow control pattern
            addresses_to_filter = [response_addr, possible_request]
            filtered_traces = _get_valid_diagnostic_frames(raw_trace_lines, addresses_to_filter)
            
            pattern = multi_frame_pattern + r'\n^.*' + possible_request.replace('-', '[ ]+') + r'[ ]+30 .*'
            matches = re.findall(pattern, filtered_traces, re.MULTILINE)
            
            if len(multi_frame_responses) == len(matches):
                request_response_pairs[possible_request] = response_addr
                break
    
    # CAN FD support - 18DAxxyy format
    remaining = dict(valid_response_without_request)
    for response_addr, request_possibilities in remaining.items():
        if len(response_addr) != 8:
            continue
        
        first_byte = response_addr[:2]
        last_bytes = response_addr[6:8] + response_addr[4:6]
        
        for req_addr in request_possibilities:
            if req_addr.startswith(first_byte) and req_addr.endswith(last_bytes):
                request_response_pairs[req_addr] = response_addr
                break

def _get_request_sid(response: str) -> str:
    """Extract request SID from response"""
    if not response:
        return ''
    
    try:
        first_byte = response[:2]
        if first_byte == "7F":
            return "7F" if len(response) <= 4 else response[2:4]
        
        sid = int(first_byte, 16) - 0x40
        return f"{sid:02X}" if sid >= 0 else ''
    except (ValueError, IndexError):
        return ''

def _club_messages(input_data: List[str]) -> Dict[str, List[str]]:
    """Club CAN frames by address"""
    can_addresses = {}
    for frame in input_data:
        parts = frame.split('\t')
        if len(parts) != 2:
            continue
        
        address, message = parts
        if address not in can_addresses:
            can_addresses[address] = []
        can_addresses[address].append(message)
    
    return can_addresses

def _remove_functional_messages(trace: List[str], request_addresses: List[str]) -> Tuple[List[str], List[str]]:
    """Remove functional messages from trace"""
    functional_messages = []
    processed_trace = []
    
    functional_address_list = FUNCTIONAL_ADDRESS_LIST.split('|')
    
    # Remove functional addresses from request addresses
    for func_addr in functional_address_list:
        if func_addr in request_addresses:
            request_addresses.remove(func_addr)
    
    reg_ex = re.compile('|'.join([f"{addr}\t" for addr in request_addresses]))
    fun_reg_ex = re.compile('|'.join([f"{addr}\t" for addr in functional_address_list]))
    
    i = 0
    while i < len(trace):
        if fun_reg_ex.search(trace[i]):
            functional_messages.append(trace[i])
            j = i + 1
            
            # Collect following responses
            while j < len(trace):
                if reg_ex.search(trace[j]):
                    break
                functional_messages.append(trace[j])
                j += 1
            
            i = j
        
        if i < len(trace):
            processed_trace.append(trace[i])
        i += 1
    
    return processed_trace, functional_messages

def _process_functional_messages(functional_messages: List[str]) -> List[TraceMessage]:
    """Process functional messages"""
    output = []
    if not functional_messages:
        return output
    
    functional_data = '\n'.join(functional_messages)
    functional_address_list = FUNCTIONAL_ADDRESS_LIST.split('|')
    match_string = '|'.join([f"{addr}\t" for addr in functional_address_list])
    
    matches = list(re.finditer(match_string, functional_data))
    if not matches:
        return output
    
    request_response_data_list = []
    
    for i, match in enumerate(matches):
        start_index = functional_data.rfind('\n', 0, match.start()) + 1
        end_index = len(functional_data) - 1
        
        if i + 1 < len(matches):
            end_index = functional_data.rfind('\n', 0, matches[i + 1].start()) + 1
        
        batch = functional_data[start_index:end_index]
        batch_lines = batch.splitlines()
        
        if len(batch_lines) <= 1:
            continue
        
        request_parts = batch_lines[0].split('\t')
        if len(request_parts) <= 1:
            continue
        
        ecu_address = request_parts[0]
        ecu_ext_addr = ecu_address.split('-')[1] if '-' in ecu_address else ""
        request = request_parts[1]
        
        if len(request) < 2:
            continue
        
        request_sid = request[:2]
        try:
            request_sid_int = int(request_sid, 16)
        except ValueError:
            continue
        
        for j in range(1, len(batch_lines)):
            request_response_data = f"{batch_lines[0]}~{batch_lines[j]}"
            if request_response_data in request_response_data_list:
                continue
            request_response_data_list.append(request_response_data)
            
            response_parts = batch_lines[j].split('\t')
            if len(response_parts) <= 1:
                continue
            
            response_address = response_parts[0]
            response = response_parts[1]
            
            # Ignore response pending
            if re.match(r'7F[A-F0-9][A-F0-9]78', response):
                continue
            
            tester_ext_addr = response_address.split('-')[1] if '-' in response_address else ""
            
            # SID validation
            expected_response_sid = f"{request_sid_int + 0x40:02X}"
            if response.startswith(expected_response_sid) or response.startswith("7F"):
                output.append(TraceMessage(
                    ecu_address=ecu_address.split('-')[0],
                    tester_address=response_address.split('-')[0],
                    request=request,
                    response=response,
                    ecu_extended_address=ecu_ext_addr,
                    tester_extended_address=tester_ext_addr
                ))
    
    return output

def _get_request_response_pairs(trace: List[str], request_address: str, response_address: str) -> Dict[str, List[str]]:
    """Get request-response pairs for specific addresses"""
    request_responses = {}
    functional_address_list = FUNCTIONAL_ADDRESS_LIST.split('|')
    
    for i, frame in enumerate(trace):
        if not frame.startswith(f"{request_address}\t"):
            continue
        
        request = frame.split('\t')[1]
        response = ""
        
        # Find responses
        for j in range(i + 1, len(trace)):
            if trace[j].startswith(f"{request_address}\t"):
                break
            
            # Check for functional addresses
            if any(trace[j].startswith(f"{func_addr}\t") for func_addr in functional_address_list):
                break
            
            if trace[j].startswith(f"{response_address}\t"):
                response_part = trace[j].split('\t')[1]
                response += f"{response_part}~"
        
        response = response.rstrip('~')
        
        if request not in request_responses:
            request_responses[request] = []
        if response and response not in request_responses[request]:
            request_responses[request].append(response)
    
    return request_responses

def _filter_trace(trace: List[str], addresses: List[str], is_pass_filter: bool = True) -> List[str]:
    """Filter trace by addresses"""
    filtered = []
    for frame in trace:
        if '\t' not in frame:
            continue
        
        address = frame.split('\t')[0]
        if is_pass_filter:
            if address in addresses:
                filtered.append(frame)
        else:
            if address not in addresses:
                filtered.append(frame)
    
    return filtered

def _get_valid_diagnostic_frames(input_data: List[str], valid_addresses: List[str], is_pass_filter: bool = True) -> str:
    """Get valid diagnostic frames as string"""
    valid_frames = []
    pattern = '|'.join([addr.replace('-', '[ ]+') for addr in valid_addresses])
    regex = re.compile(f"[ ]+({pattern})")
    
    for frame in input_data:
        frame_str = frame if isinstance(frame, str) else str(frame)
        if is_pass_filter and regex.search(frame_str):
            valid_frames.append(frame_str.strip())
        elif not is_pass_filter and not regex.search(frame_str):
            valid_frames.append(frame_str.strip())
    
    return '\n'.join(valid_frames)

def _get_valid_diagnostic_frames_as_list(input_data: List[str], valid_addresses: List[str], is_pass_filter: bool = True) -> List[str]:
    """Get valid diagnostic frames as list"""
    valid_frames = []
    pattern = '|'.join([addr.replace('-', '[ ]+') for addr in valid_addresses])
    regex = re.compile(f"[ ]+({pattern})")
    
    for frame in input_data:
        frame_str = frame if isinstance(frame, str) else str(frame)
        if is_pass_filter and regex.search(frame_str):
            valid_frames.append(frame_str.strip())
        elif not is_pass_filter and not regex.search(frame_str):
            valid_frames.append(frame_str.strip())
    
    return valid_frames