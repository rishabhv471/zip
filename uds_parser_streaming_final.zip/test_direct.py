#!/usr/bin/env python3

from uds_parser import parse_uds_trace
import json

def test_direct_parsing():
    """Test the parser directly without API."""
    
    print("Direct UDS Parser Test")
    print("=" * 30)
    
    # Test with sample file
    file_path = "/Users/vyjjqon/Desktop/pp/Data_NEW_pre/sample_trace.txt"
    
    try:
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        print(f"Testing with {len(lines)} lines from sample file...")
        
        # Parse the data
        result = parse_uds_trace(lines)
        
        print(f"Successfully parsed {len(result)} messages")
        
        # Display results in a nice format
        print("\nParsed Messages:")
        print("-" * 50)
        
        for i, msg in enumerate(result, 1):
            print(f"{i:2d}. ID: 0x{msg['id']:03X} ({msg['id']:3d}) | Data: {msg['hex_data']}")
        
        # Test with custom data
        print("\n" + "=" * 30)
        print("Testing with custom data...")
        
        custom_lines = [
            "< 165 50 c0 00 00 00 00 00 00",
            "< 167 72 80 b5 10 00 1a 9d 00",
            "< 200 00 00 7f dc 80 b6 f0 00"
        ]
        
        custom_result = parse_uds_trace(custom_lines)
        
        print(f"Custom data parsed: {len(custom_result)} messages")
        for i, msg in enumerate(custom_result, 1):
            print(f"{i}. ID: 0x{msg['id']:03X} | Data: {msg['hex_data']}")
        
        # Test performance with larger dataset
        print("\n" + "=" * 30)
        print("Performance test with 1000 messages...")
        
        large_dataset = custom_lines * 334  # ~1000 lines
        
        import time
        start_time = time.time()
        
        large_result = parse_uds_trace(large_dataset)
        
        end_time = time.time()
        
        print(f"Processed {len(large_dataset)} lines in {end_time - start_time:.4f} seconds")
        print(f"Found {len(large_result)} valid messages")
        print(f"Processing rate: {len(large_dataset) / (end_time - start_time):.0f} lines/second")
        
        return True
        
    except Exception as e:
        print(f"Error: {e}")
        return False

if __name__ == "__main__":
    success = test_direct_parsing()
    print(f"\nTest {'PASSED' if success else 'FAILED'}!")