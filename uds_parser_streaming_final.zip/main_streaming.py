from fastapi import FastAPI, UploadFile, File, HTTPException, Query
from uds_parser import parse_uds_trace, parse_samdia_trace
from uds_streaming_parser import parse_large_file_streaming, parse_uds_trace_streaming
import time
from typing import Optional

app = FastAPI(
    title="UDS Communication Trace Parser",
    description="High-performance parser for UDS communication traces with streaming support",
    version="1.0.0"
)

@app.get("/")
async def root():
    return {
        "message": "UDS Trace Parser API with Streaming Support",
        "endpoints": {
            "/parse": "Parse simple UDS trace format (streaming for large files)",
            "/parse-samdia": "Parse advanced Samdia format traces",
            "/health": "Health check"
        }
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": time.time()}

@app.post("/parse")
async def parse_simple_trace(
    file: UploadFile = File(...),
    format_type: Optional[str] = Query("simple", description="Trace format type")
):
    """
    Parse UDS trace file with streaming support for large files.
    Supports simple format like: < 165 50 c0 00 00 00 00 00 00
    """
    try:
        start_time = time.time()
        
        # Read file content
        content = await file.read()
        file_size_mb = len(content) / (1024 * 1024)
        
        # Use streaming parser for large files (>10MB)
        if file_size_mb > 10:
            print(f"Large file detected: {file_size_mb:.1f}MB - using streaming parser")
            parsed = parse_large_file_streaming(content)
            total_lines = "N/A (streamed)"
        else:
            # Use regular parser for small files
            lines = content.decode('utf-8').splitlines()
            if format_type.lower() == "simple":
                parsed = parse_uds_trace(lines)
            else:
                raise HTTPException(status_code=400, detail=f"Unsupported format: {format_type}")
            total_lines = len(lines)
        
        end_time = time.time()
        
        return {
            "status": "success",
            "filename": file.filename,
            "format": format_type,
            "file_size_mb": round(file_size_mb, 2),
            "processing_time": round(end_time - start_time, 4),
            "total_lines": total_lines,
            "parsed_messages": len(parsed),
            "streaming_used": file_size_mb > 10,
            "messages": parsed
        }
        
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File encoding not supported. Please use UTF-8.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Parsing error: {str(e)}")

@app.post("/parse-samdia")
async def parse_samdia_format(file: UploadFile = File(...)):
    """
    Parse advanced Samdia format traces with CAN frame handling.
    Handles multi-frame messages, extended addressing, and request-response pairing.
    """
    try:
        start_time = time.time()
        
        # Read file content
        content = await file.read()
        raw_data = content.decode('utf-8')
        
        # Parse using advanced Samdia parser
        parsed = parse_samdia_trace(raw_data)
        
        end_time = time.time()
        
        return {
            "status": "success",
            "filename": file.filename,
            "format": "samdia",
            "processing_time": round(end_time - start_time, 4),
            "parsed_messages": len(parsed),
            "messages": parsed
        }
        
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File encoding not supported. Please use UTF-8.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Parsing error: {str(e)}")

@app.post("/parse-text")
async def parse_text_input(trace_data: dict):
    """
    Parse UDS trace from text input (no file upload).
    Expected input: {"data": "< 165 50 c0...\n< 167 72 80..."}
    """
    try:
        start_time = time.time()
        
        if "data" not in trace_data:
            raise HTTPException(status_code=400, detail="Missing 'data' field in request body")
        
        lines = trace_data["data"].splitlines()
        
        # Use streaming parser for large text input
        if len(lines) > 50000:
            parsed = parse_uds_trace_streaming(lines)
        else:
            parsed = parse_uds_trace(lines)
        
        end_time = time.time()
        
        return {
            "status": "success",
            "format": "simple",
            "processing_time": round(end_time - start_time, 4),
            "total_lines": len(lines),
            "parsed_messages": len(parsed),
            "streaming_used": len(lines) > 50000,
            "messages": parsed
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Parsing error: {str(e)}")