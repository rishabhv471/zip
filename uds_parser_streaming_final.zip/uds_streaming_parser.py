import tempfile
import os
from typing import List, Dict, Iterator
import gc

def parse_large_file_streaming(file_content: bytes, chunk_size: int = 10000) -> List[Dict]:
    """Process large files in chunks to avoid memory crash"""
    
    # Save content to temp file for streaming
    with tempfile.NamedTemporaryFile(mode='wb', delete=False) as temp_file:
        temp_file.write(file_content)
        temp_path = temp_file.name
    
    try:
        results = []
        chunk = []
        
        with open(temp_path, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f):
                line = line.strip()
                if not line or not line.startswith('<'):
                    continue
                
                parts = line[1:].strip().split()
                if len(parts) < 2:
                    continue
                
                try:
                    msg_id = int(parts[0], 16)
                    data = [int(x, 16) for x in parts[1:]]
                    chunk.append({
                        'id': msg_id,
                        'data': data,
                        'hex_data': ' '.join(parts[1:])
                    })
                    
                    # Process chunk when full
                    if len(chunk) >= chunk_size:
                        results.extend(chunk)
                        chunk.clear()
                        gc.collect()  # Free memory
                        
                        # Progress indicator for large files
                        if len(results) % 50000 == 0:
                            print(f"Processed {len(results)} messages...")
                            
                except ValueError:
                    continue
        
        # Add remaining messages
        results.extend(chunk)
        
    finally:
        # Clean up temp file
        os.unlink(temp_path)
    
    return results

def parse_uds_trace_streaming(trace_lines: List[str], chunk_size: int = 10000) -> List[Dict]:
    """Memory-efficient parser for large line lists"""
    results = []
    chunk = []
    
    for i, line in enumerate(trace_lines):
        line = line.strip()
        if not line or not line.startswith('<'):
            continue
        
        parts = line[1:].strip().split()
        if len(parts) < 2:
            continue
        
        try:
            msg_id = int(parts[0], 16)
            data = [int(x, 16) for x in parts[1:]]
            chunk.append({
                'id': msg_id,
                'data': data,
                'hex_data': ' '.join(parts[1:])
            })
            
            # Process chunk when full
            if len(chunk) >= chunk_size:
                results.extend(chunk)
                chunk.clear()
                gc.collect()
                
                # Progress for large datasets
                if len(results) % 50000 == 0:
                    print(f"Processed {len(results)} messages...")
                    
        except ValueError:
            continue
    
    # Add remaining messages
    results.extend(chunk)
    return results