    #!/usr/bin/env python3

import uvicorn
import sys
import os

def main():
    """Start the UDS Parser API server."""
    
    print("Starting UDS Communication Trace Parser API...")
    print("=" * 50)
    
    # Configuration
    host = "127.0.0.1"
    port = 8000
    
    print(f"Server will start at: http://{host}:{port}")
    print("Available endpoints:")
    print(f"  - GET  http://{host}:{port}/          (API info)")
    print(f"  - GET  http://{host}:{port}/health    (Health check)")
    print(f"  - POST http://{host}:{port}/parse     (Parse simple format)")
    print(f"  - POST http://{host}:{port}/parse-samdia (Parse Samdia format)")
    print(f"  - POST http://{host}:{port}/parse-text   (Parse text input)")
    print(f"  - GET  http://{host}:{port}/docs      (API documentation)")
    print("=" * 50)
    
    try:
        # Start the server
        uvicorn.run(
            "main:app",
            host=host,
            port=port,
            reload=True,
            log_level="debug"
        )
    except KeyboardInterrupt:
        print("\nServer stopped by user")
    except Exception as e:
        print(f"Error starting server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()