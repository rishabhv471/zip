#!/usr/bin/env python3

import requests
import json
import time

def test_api():
    """Test the UDS Parser API endpoints."""
    
    base_url = "http://127.0.0.1:8000"
    
    print("Testing UDS Parser API...")
    print("=" * 40)
    
    # Test 1: Health check
    print("1. Testing health endpoint...")
    try:
        response = requests.get(f"{base_url}/health")
        if response.status_code == 200:
            print("   ✓ Health check passed")
        else:
            print(f"   ✗ Health check failed: {response.status_code}")
    except requests.exceptions.ConnectionError:
        print("   ✗ Cannot connect to server. Make sure it's running!")
        return
    
    # Test 2: Root endpoint
    print("2. Testing root endpoint...")
    try:
        response = requests.get(f"{base_url}/")
        if response.status_code == 200:
            data = response.json()
            print("   ✓ Root endpoint working")
            print(f"   Available endpoints: {list(data['endpoints'].keys())}")
        else:
            print(f"   ✗ Root endpoint failed: {response.status_code}")
    except Exception as e:
        print(f"   ✗ Error: {e}")
    
    # Test 3: Parse text input
    print("3. Testing text parsing...")
    try:
        sample_data = {
            "data": "< 165 50 c0 00 00 00 00 00 00\n< 167 72 80 b5 10 00 1a 9d 00"
        }
        
        response = requests.post(
            f"{base_url}/parse-text",
            json=sample_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            result = response.json()
            print("   ✓ Text parsing successful")
            print(f"   Processed {result['parsed_messages']} messages in {result['processing_time']}s")
        else:
            print(f"   ✗ Text parsing failed: {response.status_code}")
            print(f"   Response: {response.text}")
    except Exception as e:
        print(f"   ✗ Error: {e}")
    
    # Test 4: File upload (if sample file exists)
    print("4. Testing file upload...")
    try:
        file_path = "/Users/vyjjqon/Desktop/pp/Data_NEW_pre/sample_trace.txt"
        
        with open(file_path, 'rb') as f:
            files = {'file': ('sample_trace.txt', f, 'text/plain')}
            response = requests.post(f"{base_url}/parse", files=files)
        
        if response.status_code == 200:
            result = response.json()
            print("   ✓ File upload parsing successful")
            print(f"   Processed {result['parsed_messages']} messages in {result['processing_time']}s")
            print(f"   File: {result['filename']}")
        else:
            print(f"   ✗ File upload failed: {response.status_code}")
            print(f"   Response: {response.text}")
            
    except FileNotFoundError:
        print("   ⚠ Sample file not found, skipping file upload test")
    except Exception as e:
        print(f"   ✗ Error: {e}")
    
    print("=" * 40)
    print("API testing completed!")

def benchmark_api():
    """Benchmark the API performance."""
    
    base_url = "http://127.0.0.1:8000"
    
    print("\nRunning API performance benchmark...")
    
    sample_data = {
        "data": "\n".join([
            "< 165 50 c0 00 00 00 00 00 00",
            "< 167 72 80 b5 10 00 1a 9d 00",
            "< 200 00 00 7f dc 80 b6 f0 00",
            "< 202 04 db 00 00 60 00 11 10",
            "< 204 c0 99 7d 02 a1 00 00 00"
        ] * 20)  # 100 lines total
    }
    
    num_requests = 50
    times = []
    
    print(f"Sending {num_requests} requests with {len(sample_data['data'].splitlines())} lines each...")
    
    for i in range(num_requests):
        start_time = time.time()
        
        try:
            response = requests.post(
                f"{base_url}/parse-text",
                json=sample_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                end_time = time.time()
                times.append(end_time - start_time)
            else:
                print(f"Request {i+1} failed: {response.status_code}")
                
        except Exception as e:
            print(f"Request {i+1} error: {e}")
    
    if times:
        avg_time = sum(times) / len(times)
        min_time = min(times)
        max_time = max(times)
        
        print(f"\nBenchmark Results:")
        print(f"  Successful requests: {len(times)}/{num_requests}")
        print(f"  Average response time: {avg_time:.4f}s")
        print(f"  Min response time: {min_time:.4f}s")
        print(f"  Max response time: {max_time:.4f}s")
        print(f"  Requests per second: {1/avg_time:.1f}")

if __name__ == "__main__":
    test_api()
    
    # Ask user if they want to run benchmark
    try:
        run_benchmark = input("\nRun performance benchmark? (y/n): ").lower().strip()
        if run_benchmark == 'y':
            benchmark_api()
    except KeyboardInterrupt:
        print("\nTest completed!")