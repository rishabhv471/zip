#!/usr/bin/env python3

"""
UDS Communication Trace Parser Demo

This script demonstrates the complete workflow:
1. Parse UDS trace data
2. Show performance metrics
3. Display results
"""

from uds_parser import parse_uds_trace
import time
import json

def main():
    print("🚀 UDS Communication Trace Parser Demo")
    print("=" * 50)
    
    # Step 1: Load sample data
    print("📁 Step 1: Loading sample trace data...")
    
    sample_file = "/Users/vyjjqon/Desktop/pp/Data_NEW_pre/sample_trace.txt"
    
    try:
        with open(sample_file, 'r') as f:
            lines = f.readlines()
        print(f"   ✓ Loaded {len(lines)} lines from {sample_file}")
    except FileNotFoundError:
        print(f"   ⚠ Sample file not found, using hardcoded data")
        lines = [
            "< 165 50 c0 00 00 00 00 00 00\n",
            "< 167 72 80 b5 10 00 1a 9d 00\n",
            "< 200 00 00 7f dc 80 b6 f0 00\n",
            "< 202 04 db 00 00 60 00 11 10\n",
            "< 204 c0 99 7d 02 a1 00 00 00\n"
        ]
    
    # Step 2: Parse the data
    print("\n⚡ Step 2: Parsing UDS trace data...")
    
    start_time = time.time()
    parsed_messages = parse_uds_trace(lines)
    end_time = time.time()
    
    parsing_time = end_time - start_time
    
    print(f"   ✓ Parsing completed in {parsing_time:.6f} seconds")
    print(f"   ✓ Found {len(parsed_messages)} valid messages")
    
    # Step 3: Performance metrics
    print("\n📊 Step 3: Performance Analysis...")
    
    if parsing_time > 0:
        lines_per_second = len(lines) / parsing_time
        messages_per_second = len(parsed_messages) / parsing_time
        
        print(f"   • Processing rate: {lines_per_second:,.0f} lines/second")
        print(f"   • Message rate: {messages_per_second:,.0f} messages/second")
        print(f"   • Success rate: {len(parsed_messages)/len(lines)*100:.1f}%")
    
    # Step 4: Display results
    print("\n📋 Step 4: Parsed Messages...")
    print("-" * 50)
    
    for i, msg in enumerate(parsed_messages[:10], 1):  # Show first 10
        print(f"   {i:2d}. ID: 0x{msg['id']:03X} | Data: {msg['hex_data']}")
    
    if len(parsed_messages) > 10:
        print(f"   ... and {len(parsed_messages) - 10} more messages")
    
    # Step 5: Data analysis
    print(f"\n🔍 Step 5: Data Analysis...")
    
    if parsed_messages:
        # Unique message IDs
        unique_ids = set(msg['id'] for msg in parsed_messages)
        print(f"   • Unique message IDs: {len(unique_ids)}")
        print(f"   • ID range: 0x{min(unique_ids):03X} - 0x{max(unique_ids):03X}")
        
        # Data length statistics
        data_lengths = [len(msg['data']) for msg in parsed_messages]
        avg_length = sum(data_lengths) / len(data_lengths)
        print(f"   • Data length: min={min(data_lengths)}, max={max(data_lengths)}, avg={avg_length:.1f}")
        
        # Most common message IDs
        id_counts = {}
        for msg in parsed_messages:
            id_counts[msg['id']] = id_counts.get(msg['id'], 0) + 1
        
        most_common = sorted(id_counts.items(), key=lambda x: x[1], reverse=True)[:3]
        print(f"   • Most frequent IDs: {[(f'0x{id:03X}', count) for id, count in most_common]}")
    
    # Step 6: Export results (optional)
    print(f"\n💾 Step 6: Export Options...")
    
    try:
        export_choice = input("   Export results to JSON? (y/n): ").lower().strip()
        if export_choice == 'y':
            output_file = "parsed_results.json"
            
            export_data = {
                "metadata": {
                    "total_lines": len(lines),
                    "parsed_messages": len(parsed_messages),
                    "parsing_time": parsing_time,
                    "timestamp": time.time()
                },
                "messages": parsed_messages
            }
            
            with open(output_file, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            print(f"   ✓ Results exported to {output_file}")
        else:
            print("   ⏭ Skipping export")
            
    except KeyboardInterrupt:
        print("\n   ⏭ Skipping export")
    
    # Summary
    print(f"\n🎉 Demo Complete!")
    print("=" * 50)
    print(f"Summary:")
    print(f"  • Input: {len(lines)} lines")
    print(f"  • Output: {len(parsed_messages)} messages")
    print(f"  • Time: {parsing_time:.6f} seconds")
    print(f"  • Speed: {len(lines)/parsing_time:,.0f} lines/sec" if parsing_time > 0 else "  • Speed: Instant")
    
    print(f"\n🚀 Ready for production use!")
    print(f"   • Run 'python3 run_server.py' to start API server")
    print(f"   • Visit http://127.0.0.1:8000/docs for API documentation")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Demo interrupted by user. Goodbye!")
    except Exception as e:
        print(f"\n❌ Demo failed: {e}")
        print("Please check the installation and try again.")