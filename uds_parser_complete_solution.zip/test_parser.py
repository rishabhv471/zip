#!/usr/bin/env python3

from uds_parser import parse_uds_trace
import time

def test_with_sample_file():
    """Test the parser with the sample trace file."""
    
    # Hardcoded file path as requested
    file_path = "/Users/vyjjqon/Desktop/pp/Data_NEW_pre/sample_trace.txt"
    
    print("Testing UDS Parser with sample file...")
    print(f"File: {file_path}")
    
    try:
        # Read the file
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        print(f"Read {len(lines)} lines from file")
        
        # Measure parsing time
        start_time = time.time()
        
        # Parse the trace
        parsed_messages = parse_uds_trace(lines)
        
        end_time = time.time()
        parsing_time = end_time - start_time
        
        # Display results
        print(f"\nParsing completed in {parsing_time:.4f} seconds")
        print(f"Found {len(parsed_messages)} valid messages")
        
        # Show first few messages
        print("\nFirst 5 parsed messages:")
        for i, msg in enumerate(parsed_messages[:5]):
            print(f"  {i+1}. ID: 0x{msg['id']:03X}, Data: {msg['hex_data']}")
        
        # Show statistics
        if parsed_messages:
            unique_ids = set(msg['id'] for msg in parsed_messages)
            print(f"\nStatistics:")
            print(f"  Unique message IDs: {len(unique_ids)}")
            print(f"  Message IDs: {sorted(unique_ids)}")
            
            # Data length distribution
            data_lengths = [len(msg['data']) for msg in parsed_messages]
            print(f"  Data lengths: min={min(data_lengths)}, max={max(data_lengths)}, avg={sum(data_lengths)/len(data_lengths):.1f}")
        
        return parsed_messages
        
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return None
    except Exception as e:
        print(f"Error during parsing: {e}")
        return None

def performance_test():
    """Test parser performance with repeated parsing."""
    
    file_path = "/Users/vyjjqon/Desktop/pp/Data_NEW_pre/sample_trace.txt"
    
    try:
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        print(f"\nPerformance Test - parsing {len(lines)} lines 100 times...")
        
        start_time = time.time()
        
        for i in range(100):
            parse_uds_trace(lines)
        
        end_time = time.time()
        total_time = end_time - start_time
        
        print(f"Total time for 100 iterations: {total_time:.4f} seconds")
        print(f"Average time per parse: {total_time/100:.6f} seconds")
        print(f"Messages per second: {len(lines) * 100 / total_time:.0f}")
        
    except Exception as e:
        print(f"Performance test failed: {e}")

if __name__ == "__main__":
    # Run basic test
    messages = test_with_sample_file()
    
    # Run performance test if basic test succeeded
    if messages is not None:
        performance_test()
    
    print("\nTest completed!")