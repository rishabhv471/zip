import re
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass

@dataclass
class TraceMessage:
    ecu_address: str
    tester_address: str
    request: str
    response: str
    ecu_extended_address: str = ""
    tester_extended_address: str = ""

def parse_uds_trace(trace_lines: List[str]) -> List[Dict]:
    """
    Efficiently parses UDS communication trace lines.
    Handles simple format like: < 165 50 c0 00 00 00 00 00 00
    """
    result = []
    for line in trace_lines:
        line = line.strip()
        if not line or not line.startswith('<'):
            continue
        parts = line[1:].strip().split()
        if len(parts) < 2:
            continue
        try:
            msg_id = int(parts[0], 16)
            data = [int(x, 16) for x in parts[1:]]
            result.append({
                'id': msg_id, 
                'data': data,
                'hex_data': ' '.join(parts[1:])
            })
        except ValueError:
            continue
    return result

def parse_samdia_trace(raw_data: str) -> List[TraceMessage]:
    """
    Advanced parser for Samdia format traces with CAN frame handling.
    Based on the C# SamdiaPreProcessor logic.
    """
    # Prepare trace for processing
    prepared_lines = _prepare_trace_for_processing(raw_data)
    
    if not prepared_lines:
        return []
    
    # Get valid CAN IDs
    valid_can_ids, valid_can_ids_with_ext = _get_valid_can_ids(prepared_lines)
    
    # Merge CAN frames
    merged_frames = _merge_can_frames(prepared_lines, valid_can_ids, valid_can_ids_with_ext)
    
    # Find request-response pairs
    request_response_pairs = _find_request_response_pairs(merged_frames, prepared_lines)
    
    # Process messages
    trace_data = []
    for req_addr, resp_addr in request_response_pairs.items():
        ecu_address = req_addr.split('-')[0]
        tester_address = resp_addr.split('-')[0]
        
        filtered_trace = _filter_trace(merged_frames, [req_addr, resp_addr])
        req_resp_pairs = _get_request_response_pairs(filtered_trace, req_addr, resp_addr)
        
        for request, responses in req_resp_pairs.items():
            for response in responses:
                trace_data.append(TraceMessage(
                    ecu_address=ecu_address,
                    tester_address=tester_address,
                    request=request,
                    response=response
                ))
    
    return [msg.__dict__ for msg in trace_data]

def _prepare_trace_for_processing(trace: str) -> List[str]:
    """Prepare trace by cleaning timestamps and formatting."""
    output = []
    regex1 = re.compile(r'([0-9][0-9]:[0-9][0-9]:[0-9][0-9].[0-9][0-9][0-9].[0-9][0-9][0-9])')
    regex2 = re.compile(r'  .*        ')
    
    for line in trace.splitlines():
        cleaned = regex2.sub(' ', regex1.sub(' ', line)).upper().strip()
        if cleaned:
            output.append(cleaned + '\n')
    return output

def _get_valid_can_ids(input_data: List[str]) -> Tuple[List[str], List[str]]:
    """Extract valid CAN IDs from trace data."""
    can_addresses = _get_can_addresses(input_data)
    valid_can_ids = []
    valid_can_ids_with_ext = []
    
    for address, messages in can_addresses.items():
        if _is_valid_diagnostic_frames(messages):
            valid_can_ids.append(address)
            valid_can_ids_with_ext.append(address)
    
    return valid_can_ids, valid_can_ids_with_ext

def _get_can_addresses(input_data: List[str]) -> Dict[str, List[str]]:
    """Extract CAN addresses and their payloads."""
    can_addresses = {}
    
    for line in input_data:
        address, payload = _get_address(line)
        if address and payload:
            if address not in can_addresses:
                can_addresses[address] = []
            can_addresses[address].append(payload)
    
    return can_addresses

def _get_address(can_frame: str) -> Tuple[str, str]:
    """Extract address and payload from CAN frame."""
    # Handle 11-bit address
    match = re.search(r' [A-F0-9]{3} ', can_frame)
    if not match:
        # Handle 29-bit address
        match = re.search(r' [A-F0-9]{8} ', can_frame)
    
    if not match:
        return '', ''
    
    address = match.group().strip()
    payload = can_frame[can_frame.index(match.group()):].replace(address, '').strip()
    payload = payload.replace(' ', '')
    
    return address, payload

def _is_valid_diagnostic_frames(can_messages: List[str]) -> bool:
    """Check if CAN messages are valid diagnostic frames."""
    if not can_messages:
        return False
    
    valid_frames = 0
    for message in can_messages:
        if not re.match(r'^[A-F0-9]+$', message):
            continue
        
        if len(message) < 4:
            continue
            
        # Check if it starts with flow control (30)
        if message.startswith('30'):
            valid_frames += 1
            continue
            
        length_byte = int(message[:2], 16)
        if length_byte < 1:
            continue
            
        valid_frames += 1
    
    return valid_frames > len(can_messages) * 0.8

def _merge_can_frames(input_data: List[str], valid_can_ids: List[str], valid_can_ids_with_ext: List[str]) -> List[str]:
    """Merge multi-frame CAN messages."""
    output = []
    i = 0
    
    while i < len(input_data):
        address, payload = _get_address(input_data[i])
        
        if not address or not payload or address not in valid_can_ids:
            i += 1
            continue
            
        if len(payload) < 4:
            i += 1
            continue
            
        first_byte = payload[:2]
        message = payload[2:]
        
        # Single frame
        if not payload.startswith('1'):
            length = int(first_byte, 16)
            if len(message) >= length * 2:
                valid_message = message[:length * 2]
                output.append(f"{address}\t{valid_message}")
            i += 1
            continue
            
        # Multi-frame message
        if payload.startswith('1'):
            length = int(payload[1:4], 16)
            message = payload[4:]
            
            # Look for continuation frames
            j = i + 1
            frame_count = 1
            
            while j < len(input_data) and len(message) < length * 2:
                next_addr, next_payload = _get_address(input_data[j])
                if next_addr != address:
                    j += 1
                    continue
                    
                if next_payload.startswith(f'2{frame_count:X}'):
                    message += next_payload[2:]
                    frame_count += 1
                    if frame_count == 16:
                        frame_count = 0
                j += 1
                
            if len(message) >= length * 2:
                valid_message = message[:length * 2]
                output.append(f"{address}\t{valid_message}")
                
        i += 1
    
    return output

def _find_request_response_pairs(merged_frames: List[str], raw_trace: List[str]) -> Dict[str, str]:
    """Find request-response address pairs."""
    # Simplified version - in real implementation this would be more complex
    pairs = {}
    addresses = set()
    
    for frame in merged_frames:
        if '\t' in frame:
            addr = frame.split('\t')[0]
            addresses.add(addr)
    
    # Simple pairing logic - pair consecutive addresses
    addr_list = sorted(addresses)
    for i in range(0, len(addr_list) - 1, 2):
        pairs[addr_list[i]] = addr_list[i + 1]
    
    return pairs

def _filter_trace(trace: List[str], addresses: List[str]) -> List[str]:
    """Filter trace to only include specified addresses."""
    filtered = []
    for frame in trace:
        if '\t' in frame:
            addr = frame.split('\t')[0]
            if addr in addresses:
                filtered.append(frame)
    return filtered

def _get_request_response_pairs(trace: List[str], req_addr: str, resp_addr: str) -> Dict[str, List[str]]:
    """Extract request-response message pairs."""
    pairs = {}
    
    for i, frame in enumerate(trace):
        if not frame.startswith(req_addr + '\t'):
            continue
            
        request = frame.split('\t')[1]
        
        # Look for responses
        responses = []
        for j in range(i + 1, len(trace)):
            if trace[j].startswith(req_addr + '\t'):
                break
            if trace[j].startswith(resp_addr + '\t'):
                responses.append(trace[j].split('\t')[1])
        
        if request not in pairs:
            pairs[request] = []
        pairs[request].extend(responses)
    
    return pairs