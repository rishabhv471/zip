#!/usr/bin/env python3

from uds_parser import parse_samdia_trace
import time

def test_samdia_parsing():
    """Test the complete Samdia parser functionality"""
    
    print("Advanced Samdia Parser Test")
    print("=" * 40)
    
    # Test 1: Simple Samdia format
    print("Test 1: Basic Samdia format...")
    
    samdia_data = """
12:34:56.789.123  7E0 10 14 22 F1 90 00 00 00
12:34:56.790.456  7E8 30 00 14 00 00 00 00 00
12:34:56.791.789  7E0 21 01 02 03 04 05 06 07
12:34:56.792.012  7E0 22 08 09 0A 0B 0C 0D 0E
12:34:56.793.345  7E8 62 F1 90 AA BB CC DD EE
"""
    
    try:
        start_time = time.time()
        result = parse_samdia_trace(samdia_data)
        end_time = time.time()
        
        print(f"   ✓ Parsed {len(result)} messages in {end_time - start_time:.6f}s")
        
        for i, msg in enumerate(result, 1):
            print(f"   {i}. ECU: {msg['ecu_address']} -> Tester: {msg['tester_address']}")
            print(f"      Request: {msg['request']}")
            print(f"      Response: {msg['response']}")
        
    except Exception as e:
        print(f"   ✗ Test 1 failed: {e}")
    
    # Test 2: Extended addressing
    print("\nTest 2: Extended addressing...")
    
    extended_data = """
12:34:56.789.123  7E0 DF 10 14 22 F1 90 00 00
12:34:56.790.456  7E8 F1 30 00 14 00 00 00 00
12:34:56.791.789  7E0 DF 21 01 02 03 04 05 06
12:34:56.792.012  7E8 F1 62 F1 90 AA BB CC DD
"""
    
    try:
        start_time = time.time()
        result = parse_samdia_trace(extended_data)
        end_time = time.time()
        
        print(f"   ✓ Extended addressing parsed {len(result)} messages in {end_time - start_time:.6f}s")
        
        for i, msg in enumerate(result, 1):
            print(f"   {i}. ECU: {msg['ecu_address']} (Ext: {msg['ecu_extended_address']}) -> Tester: {msg['tester_address']} (Ext: {msg['tester_extended_address']})")
        
    except Exception as e:
        print(f"   ✗ Test 2 failed: {e}")
    
    # Test 3: Functional addressing
    print("\nTest 3: Functional addressing...")
    
    functional_data = """
12:34:56.789.123  7DF 22 F1 90 00 00 00 00 00
12:34:56.790.456  7E8 62 F1 90 AA BB CC DD EE
12:34:56.791.789  7E9 62 F1 90 11 22 33 44 55
"""
    
    try:
        start_time = time.time()
        result = parse_samdia_trace(functional_data)
        end_time = time.time()
        
        print(f"   ✓ Functional addressing parsed {len(result)} messages in {end_time - start_time:.6f}s")
        
        for i, msg in enumerate(result, 1):
            print(f"   {i}. ECU: {msg['ecu_address']} -> Tester: {msg['tester_address']}")
            print(f"      Request: {msg['request']} | Response: {msg['response']}")
        
    except Exception as e:
        print(f"   ✗ Test 3 failed: {e}")
    
    # Test 4: Performance test
    print("\nTest 4: Performance test...")
    
    # Generate larger dataset
    large_data = ""
    for i in range(100):
        large_data += f"""
12:34:56.{i:03d}.123  7E0 22 F1 {i:02X} 00 00 00 00 00
12:34:56.{i:03d}.456  7E8 62 F1 {i:02X} AA BB CC DD EE
"""
    
    try:
        start_time = time.time()
        result = parse_samdia_trace(large_data)
        end_time = time.time()
        
        processing_time = end_time - start_time
        lines_processed = len(large_data.splitlines())
        
        print(f"   ✓ Performance test completed")
        print(f"   • Processed {lines_processed} lines in {processing_time:.6f}s")
        print(f"   • Found {len(result)} messages")
        print(f"   • Rate: {lines_processed/processing_time:,.0f} lines/second")
        
    except Exception as e:
        print(f"   ✗ Test 4 failed: {e}")
    
    # Test 5: Error handling
    print("\nTest 5: Error handling...")
    
    invalid_data = """
Invalid line format
12:34:56.789.123  INVALID_ADDRESS 22 F1 90
12:34:56.790.456  7E8 INVALID_HEX_DATA
"""
    
    try:
        result = parse_samdia_trace(invalid_data)
        print(f"   ✓ Error handling test passed - parsed {len(result)} valid messages")
        
    except Exception as e:
        print(f"   ✓ Error handling test passed - gracefully handled: {type(e).__name__}")
    
    print("\n" + "=" * 40)
    print("Samdia parser testing completed!")

if __name__ == "__main__":
    test_samdia_parsing()